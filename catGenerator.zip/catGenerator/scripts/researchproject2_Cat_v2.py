import maya.mel as mel
import maya.cmds as cmds
import os as os
from functools import partial
import maya.OpenMaya as om


'''
GLOBAL VARIABLE & COUNTERS TO COUNT TIME AND TIMES PRESSING BUTTON TO HELP ADJUST SENSITIVITY FOR DIRECTION BUTTONS
related function: def moveSDirection()
'''
#   COUNT NUMBER TIMES PRESSED   #
# Counter to keep track how many times YUp is pressed
moveYUpCounter = 0
jnts = []
constraint = []
bboxes = {}
'''
Functions listed are basic functions that can directly modify the cat in the cat generator:
    *MODELING TAB*
    
    *Change the length of specified geo group, such as arms and legs*
        changeArmLength(length)- the arm can be changed by scaling geo between 0.7 and 1.2

    *grab the body and make it thick or skinny
        changeBodyThickness(*args)- clicking the slider, will make the body thin or thick.

    *scale the Y axis of the legs to create the illusion of having longer or shorter legs.
        changeLegLength(*args)- make the legs long or short.

    *grab the joints of binded mesh tail& rotate it
        tailCurl(*args)- clicking the slider, will make tail joints curl to a certain angle


    *grab the joints of binded mesh tail& scale it to make it look like the tail is lengthening
        tailStretch(*args)- clicking the slider, will make tail joints curl to a certain angle

    *Changing body parts by clicking on GUI button*
        setLayersVisibility(value, bodypart)- toggle on and off for all layers of a certain bodypart 
        setOnLayerVisibility(chosenLayer)- turn on specified layer 
            when used, toggle off all layers of body part, then turn on specified layer
    
    *COLORING TAB*
    
    *color the parts of the body of the cat given by the chosen color value reflected from the GUI.
        assignColorBase(*args): assign color to body of the Cat
        assignColorHead(*args): assign color to hat/faceA of the Cat
        assignColorIris(*args): assign color to eyeIris of the Cat
        assignMaterialsToOne(*args): clear all materials and restore the Cat to default material.
    
    *RIGGING TAB*
    
    *proceed with the rigging process and mute modeling process. Cancelling the Rig process will
    make the rig be deleted.
        rigIconRig(): click to proceed with Rig tab.
'''


def changeArmLength(*args):
    armGroup = 'armA'
    translateX = 'scaleX'
    arms = cmds.ls(armGroup, tr=True)
    armLength = cmds.floatSliderGrp(armSlider, q=True, v=True)
    cmds.select(arms)
    cmds.setAttr(arms[0] + '.' + translateX, armLength)

    # make the body thin or thick


def changeBodyThickness(*args):
    bodyGroup = 'body'
    attrX = 'scaleX'
    body = cmds.ls(bodyGroup, tr=True)
    bodyThickness = cmds.floatSliderGrp(bodySlider, q=True, v=True)
    cmds.select(body)
    cmds.setAttr(body[0] + '.' + attrX, bodyThickness)

    # make the legas long or short


def changeLegLength(*args):
    legGroup = 'leg'
    attrY = 'scaleY'
    selectLegGroup = cmds.ls('leg*', tr=True)
    legLength = cmds.floatSliderGrp(legSlider, q=True, v=True)
    cmds.select(selectLegGroup)
    for l in selectLegGroup[0:]:
        cmds.scale(1, legLength, 1, l, pivot=(0, 2.722, 0))

    # change all joints in tail to curve it


def tailCurl(*args):
    tailList = ['tailA', 'tailB', 'tailC', 'tailD']
    for l in tailList[0:]:
        tailjoints = cmds.ls(l + 'joint*', tr=True)
        tailDegree = cmds.intSliderGrp(tailCurveSlider, q=True, v=True)
        selectiontail = cmds.select(tailjoints)
        cmds.rotate(0, 0, tailDegree, a=True)


# change all joints in tail to lengthen it
def tailStretch(*args):
    tailList = ['tailA', 'tailB', 'tailC', 'tailD']
    for l in tailList[0:]:
        tailjoints = cmds.ls(l + 'joint*', tr=True)
        tailLength = cmds.floatSliderGrp(tailStretchSlider, q=True, v=True)
        selectiontail = cmds.select(tailjoints)
        cmds.scale(tailLength, 1, 1, pivot=(0, -0.5, -10))


# toggle on and off everything of a layer type
def setLayersVisibility(value, bodypart):
    # turn selected body part to string
    bodypartName = str(bodypart)
    # select all layers with the body part name and turn them on/off
    layers = cmds.ls(bodypartName + '*', long=True, type='displayLayer')
    for l in layers[0:]:
        cmds.setAttr('%s.visibility' % l, value)
        selectionStatus = cmds.layerButton(l, query=True, select=True)
        if value > 0:
            flipOff = cmds.layerButton(l, edit=True, layerVisible=True)
        else:
            flipOff = cmds.layerButton(l, edit=True, layerVisible=False)
    return flipOff


# toggle on only one layer selected by the button
def setOnLayerVisibility(chosenLayer):
    # turn selected body Layer to string name
    turnOnLayer = cmds.ls(chosenLayer, long=True, type='displayLayer')
    cmds.setAttr(turnOnLayer[0] + '.visibility', 1)
    flipOn = cmds.layerButton(turnOnLayer, edit=True, layerVisible=True)
    return flipOn


'''
    GUI window functions: functions below is used to generate the GUI window for users to use easily
        convert(s): converts a specified path into string to use to generate relative image path
        getpath(): will search in the given list of files and return the corresponding path to show images
'''

'''
following part of script is to toggle on off the gui portion for face selection.
'''


# button function to flip headA on
def chooseFaceA(*args):
    setLayersVisibility(0, 'head')
    setOnLayerVisibility('headLayerA')
    cmds.iconTextCheckBox(shfFace2, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace3, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace4, edit=True, v=False)


# button function to flip headB on
def chooseFaceB(*args):
    setLayersVisibility(0, 'head')
    setOnLayerVisibility('headLayerB')
    cmds.iconTextCheckBox(shfFace1, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace3, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace4, edit=True, v=False)


# button function to flip headC on
def chooseFaceC(*args):
    setLayersVisibility(0, 'head')
    setOnLayerVisibility('headLayerC')
    cmds.iconTextCheckBox(shfFace1, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace2, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace4, edit=True, v=False)


# button function to flip headD on
def chooseFaceD(*args):
    setLayersVisibility(0, 'head')
    setOnLayerVisibility('headLayerD')
    cmds.iconTextCheckBox(shfFace1, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace2, edit=True, v=False)
    cmds.iconTextCheckBox(shfFace3, edit=True, v=False)


'''
following part of script is to toggle on off the gui portion for ear selection.
'''


# button function to flip headA on
def chooseEarA(*args):
    setLayersVisibility(0, 'ear')
    setOnLayerVisibility('earLayerA')
    cmds.iconTextCheckBox(shfEar2, edit=True, v=False)
    cmds.iconTextCheckBox(shfEar3, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfEar4, edit=True, v=False)
    return end


# button function to flip headB on
def chooseEarB(*args):
    setLayersVisibility(0, 'ear')
    setOnLayerVisibility('earLayerB')
    cmds.iconTextCheckBox(shfEar1, edit=True, v=False)
    cmds.iconTextCheckBox(shfEar3, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfEar4, edit=True, v=False)
    return end


# button function to flip headC on
def chooseEarC(*args):
    setLayersVisibility(0, 'ear')
    setOnLayerVisibility('earLayerC')
    cmds.iconTextCheckBox(shfEar1, edit=True, v=False)
    cmds.iconTextCheckBox(shfEar2, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfEar4, edit=True, v=False)
    return end


# button function to flip headD on
def chooseEarD(*args):
    setLayersVisibility(0, 'ear')
    setOnLayerVisibility('earLayerD')
    cmds.iconTextCheckBox(shfEar1, edit=True, v=False)
    cmds.iconTextCheckBox(shfEar2, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfEar3, edit=True, v=False)
    return end


'''
following part of script is to toggle on off the gui portion for ear selection.
can change leg length in script above
'''


# button function to flip legA on
def chooseLegA(*args):
    setLayersVisibility(0, 'leg')
    setOnLayerVisibility('legLayerA')
    end = cmds.iconTextCheckBox(shfLeg2, edit=True, v=False)
    return end


def chooseLegB(*args):
    setLayersVisibility(0, 'leg')
    setOnLayerVisibility('legLayerB')
    end = cmds.iconTextCheckBox(shfLeg1, edit=True, v=False)
    return end


'''
following part of script is to toggle on off the gui portion for tail selection.
'''


# button function to flip tailA on
def chooseTailA(*args):
    setLayersVisibility(0, 'tail')
    setOnLayerVisibility('tailLayerA')
    cmds.iconTextCheckBox(shfTail2, edit=True, v=False)
    cmds.iconTextCheckBox(shfTail3, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfTail4, edit=True, v=False)
    return end


# button function to flip headB on
def chooseTailB(*args):
    setLayersVisibility(0, 'tail')
    setOnLayerVisibility('tailLayerB')
    cmds.iconTextCheckBox(shfTail1, edit=True, v=False)
    cmds.iconTextCheckBox(shfTail3, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfTail4, edit=True, v=False)
    return end


# button function to flip headC on
def chooseTailC(*args):
    setLayersVisibility(0, 'tail')
    setOnLayerVisibility('tailLayerC')
    cmds.iconTextCheckBox(shfTail1, edit=True, v=False)
    cmds.iconTextCheckBox(shfTail2, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfTail4, edit=True, v=False)
    return end


# button function to flip headD on
def chooseTailD(*args):
    setLayersVisibility(0, 'tail')
    setOnLayerVisibility('tailLayerD')
    cmds.iconTextCheckBox(shfTail1, edit=True, v=False)
    cmds.iconTextCheckBox(shfTail2, edit=True, v=False)
    end = cmds.iconTextCheckBox(shfTail3, edit=True, v=False)
    return end


'''
following part of script is the coloring functions used.
'''


# assign color to head, arms, body, leg and tail
def assignColorBase(*args):
    strSelectionLayerA = 'head*'
    strSelectionLayerB = 'leg*'
    strSelectionLayerC = 'arm*'
    strSelectionLayerD = 'tail*'
    strSelectionLayerE = 'body*'
    strSelectionLayerF = 'face*'

    selectionA = cmds.ls(strSelectionLayerA + '*', tr=True)
    for p, mesh in enumerate(selectionA):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(mesh)
        cmds.hyperShade(a=shader)

    selectionB = cmds.ls(strSelectionLayerB + '*', tr=True)
    for p, mesh in enumerate(selectionB):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(mesh)
        cmds.hyperShade(a=shader)

    selectionC = cmds.ls(strSelectionLayerC + '*', tr=True)
    for p, mesh in enumerate(selectionC):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(mesh)
        cmds.hyperShade(a=shader)
    selectionD = cmds.ls(strSelectionLayerD + '*', tr=True)
    for p, mesh in enumerate(selectionD):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(mesh)
        cmds.hyperShade(a=shader)
    selectionE = cmds.ls(strSelectionLayerE + '*', tr=True)
    for p, mesh in enumerate(selectionE):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(mesh)
        cmds.hyperShade(a=shader)
    selectionF = cmds.ls(strSelectionLayerF + '*', tr=True)
    for p, mesh in enumerate(selectionF):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(mesh)
        cmds.hyperShade(a=shader)
    return mesh


# button function to set color to hat/faceA
def assignColorHead(*args):
    strSelectionLayer = 'hatA'
    selection = cmds.ls(strSelectionLayer + '*', tr=True)
    for p, mesh in enumerate(selection):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(mesh)
        mesh = cmds.hyperShade(a=shader)
    return mesh


# assign color to eyeIris
def assignColorIris(*args):
    selection = cmds.ls('eyeIris*', tr=True)
    for p, meshIris in enumerate(selection):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(meshIris)
        finishIris = cmds.hyperShade(a=shader)
    return finishIris


# assign color to eyewhites
def assignColorEye(*args):
    selection = cmds.ls('eyeWhite*', tr=True)
    for p, meshIris in enumerate(selection):
        # assign shader to obj
        shader = cmds.shadingNode('aiStandardSurface', asShader=1, name='NUM_' + str(p))

        # assign color
        hat_color = cmds.colorInputWidgetGrp(n_color, query=True, rgb=True)
        cmds.setAttr((shader + '.baseColor'), hat_color[0], hat_color[1], hat_color[2], type='double3')

        cmds.select(meshIris)
        finishIris = cmds.hyperShade(a=shader)
    return finishIris


# assign all objects with a lambert material and clear materials
def assignMaterialsToOne(*args):
    selection = cmds.ls(tr=True)
    for l in selection[0:]:
        if cmds.objExists(l):
            shd = cmds.shadingNode('lambert', name="%s_lambert" % l, asShader=True)
            shdSG = cmds.sets(name='%sSG' % shd, empty=True, renderable=True, noSurfaceShader=True)
            cmds.connectAttr('%s.outColor' % shd, '%s.surfaceShader' % shdSG)
            cmds.sets(l, e=True, forceElement=shdSG)
    # clean up all unused nodes
    end = mel.eval('hyperShadePanelMenuCommand("hyperShadePanel1", "deleteUnusedNodes");')
    return end


'''
following part of script is to toggle on off the gui UI to turn on and off Modeling/Rigging tabs.
'''


# when rig tab is enabled, mute model tab
def muteModelTab():
    rigTab_enabled = cmds.columnLayout(rigColumnModel, query=True, vis=True)
    cmds.rowLayout(shfFace, edit=rigTab_enabled, enable=False)
    cmds.rowLayout(shfEar, edit=rigTab_enabled, enable=False)
    cmds.rowLayout(shfLeg, edit=rigTab_enabled, enable=False)
    cmds.rowLayout(shfTail, edit=rigTab_enabled, enable=False)
    cmds.floatSliderGrp(armSlider, edit=rigTab_enabled, enable=False)
    cmds.floatSliderGrp(legSlider, edit=rigTab_enabled, enable=False)
    cmds.floatSliderGrp(bodySlider, edit=rigTab_enabled, enable=False)
    cmds.floatSliderGrp(tailStretchSlider, edit=rigTab_enabled, enable=False)
    end = cmds.intSliderGrp(tailCurveSlider, edit=rigTab_enabled, enable=False)
    return end


# unmute model tab to return to modeling stage
def unmuteModelTab():
    rigTab_disabled = cmds.checkBoxGrp(returnIconModel, query=True, vis=True)
    cmds.rowLayout(shfFace, edit=rigTab_disabled, enable=True)
    cmds.rowLayout(shfEar, edit=rigTab_disabled, enable=True)
    cmds.rowLayout(shfLeg, edit=rigTab_disabled, enable=True)
    cmds.rowLayout(shfTail, edit=rigTab_disabled, enable=True)
    cmds.floatSliderGrp(armSlider, edit=rigTab_disabled, enable=True)
    cmds.floatSliderGrp(legSlider, edit=rigTab_disabled, enable=True)
    cmds.floatSliderGrp(bodySlider, edit=rigTab_disabled, enable=True)
    cmds.floatSliderGrp(tailStretchSlider, edit=rigTab_disabled, enable=True)
    end = cmds.intSliderGrp(tailCurveSlider, edit=rigTab_disabled, enable=True)
    return end


# mute rig tab in modeling process
def muteRigTab():
    rigTab_enabled = cmds.iconTextCheckBox(rigIconModel, query=True, vis=False)
    cmds.rowLayout(deleteHFreezeTrColumn, enable=rigTab_enabled)
    cmds.columnLayout(rigStartColumn, enable= rigTab_enabled)
    cmds.button(unlockLocationStageIcon, vis= rigTab_enabled)
    cmds.button(goBackStageIcon, vis=rigTab_enabled)
    cmds.columnLayout(stageThreeRigTab, enable=rigTab_enabled)
    cmds.rowLayout(moveYUpTab, edit=True, enable=rigTab_enabled)
    cmds.rowLayout(moveXZTab, edit=True, enable=rigTab_enabled)
    cmds.rowLayout(moveYDownTab, edit=True, enable=rigTab_enabled)

# unmute rig tab to start with rigging process
def unmuteRigTab():
    rigTab_enabled = cmds.columnLayout(rigColumnModel, query=True, vis=True)


# if check on rig ask box, message in mod tab will appear, and rig ask box will be frozen.
def enableColumnLayoutvis(columnLayout, *args):
    cmds.checkBoxGrp(returnIconModel, edit=True, enable=True, vis=False, v1=False, v2=False)
    cmds.columnLayout(columnLayout, edit=True, enable=True, vis=True)
    muteModelTab()
    cmds.iconTextCheckBox(rigIconRig, edit=True, enable=False, di=uIconPicA)
    cmds.columnLayout(rigStartColumn, edit=True, enable=True)
    resetVariables()
    om.MGlobal.displayWarning('You are now in Rigging Mode!')


def disableColumnLayoutvis(columnLayout, *args):
    # turn off model tab question & resume Modeling
    checkboxOnOff(returnIconModel)
    unmuteModelTab()
    muteRigTab()
    cmds.iconTextCheckBox(rigIconRig, edit=True, enable=True, v=False)
    cmds.iconTextCheckBox(rigIconModel, edit=True, enable=True, v=False)
    cmds.columnLayout(columnLayout, edit=True, enable=False, vis=False)


# make sure check box A is on and B is off, vice versa
def checkboxOnOff(checkboxName, *args):
    returnCheckboxA = cmds.checkBoxGrp(checkboxName, query=True, v1=True)
    cmds.checkBoxGrp(returnIconModel, edit=returnCheckboxA, v2=False)
    returnCheckboxB = cmds.checkBoxGrp(checkboxName, query=True, v2=True)
    cmds.checkBoxGrp(returnIconModel, edit=returnCheckboxB, v1=False)


def enableColumnLayout(columnLayout, *args):
    # enable column layout
    cmds.columnLayout(columnLayout, edit=True, enable=True)


def disableColumnLayout(columnLayout, *args):
    columnLayoutEval = eval(columnLayout)
    cmds.columnLayout(columnLayoutEval, edit=True, enable=False, vis=False)


def enablecheckBoxGrpvis(checkBoxGrp, *args):
    # enable checkBoxGrp layout
    checkBoxGrpEval = eval(checkBoxGrp)
    cmds.checkBoxGrp(checkBoxGrpEval, edit=True, enable=True, vis=True)
    om.MGlobal.displayWarning("Returning back to Modeling Stage will let you loose your rig!")


def disablecheckBoxGrpvis(checkBoxGrp, *args):
    # disable checkBoxGrp layout
    cmds.iconTextCheckBox(rigIconModel, edit=True, enable=True, v=False)
    cmds.iconTextCheckBox(rigIconRig, edit=True, enable=False, di=uIconPicA)
    checkBoxGrpEval = eval(checkBoxGrp)
    cmds.checkBoxGrp(checkBoxGrpEval, edit=True, enable=True, vis=False)


# unbind all tails to start with binding process
def unbindTail(*args):
    tail = 'tail'
    A = 'A'
    B = 'B'
    C = 'C'
    D = 'D'
    joints = 'joint1'
    try:
        # show button to unlock locked stage 1
        cmds.button(unlockBindTailIcon, edit=True, enable=True, vis=True)
        # lock stage 1
        cmds.iconTextCheckBox(rigIconUnbindTail, edit=True, enable=False, di=uIconPicA)
        # detach tail A
        chooseJointA = cmds.ls(tail + A + joints, tr=True)
        cmds.select(chooseJointA)
        chooseMeshA = cmds.ls(tail + A, tr=True)
        cmds.select(chooseMeshA, tgl=True)
        for i in chooseJointA:
            bindPose = mel.eval('gotoBindPose')
            detachTailA = mel.eval('doDetachSkin "2" { "2","1" }')
            cmds.select(clear=True)
        # detach tail B
        chooseJointB = cmds.ls(tail + B + joints, tr=True)
        cmds.select(chooseJointB)
        chooseMeshB = cmds.ls(tail + B, tr=True)
        cmds.select(chooseMeshB, tgl=True)
        for i in chooseJointB:
            bindPose = mel.eval('gotoBindPose')
            detachTailB = mel.eval('doDetachSkin "2" { "2","1" }')
            cmds.select(clear=True)
        # detach tail C
        chooseJointC = cmds.ls(tail + C + joints, tr=True)
        cmds.select(chooseJointC)
        chooseMeshC = cmds.ls(tail + C, tr=True)
        cmds.select(chooseMeshC, tgl=True)
        for i in chooseJointC:
            bindPose = mel.eval('gotoBindPose')
            detachTailC = mel.eval('doDetachSkin "2" { "2","1" }')
            cmds.select(clear=True)
        # detach tail D
        chooseJointD = cmds.ls(tail + D + joints, tr=True)
        cmds.select(chooseJointD)
        chooseMeshD = cmds.ls(tail + C, tr=True)
        cmds.select(chooseMeshD, tgl=True)
        for i in chooseJointD:
            bindPose = mel.eval('gotoBindPose')
            detachTailD = mel.eval('doDetachSkin "2" { "2","1" }')
            cmds.select(clear=True)
        om.MGlobal.displayWarning("Your cat is now in binding pose...Do you want to clean your cat now?")
        # unlock cleaning stage
        cmds.rowLayout(deleteHFreezeTrColumn, edit=True, enable=True)
        #unlock move directions
        cmds.rowLayout(moveYUpTab, edit=True, enable=True)
        cmds.rowLayout(moveXZTab, edit=True, enable=True)
        cmds.rowLayout(moveYDownTab, edit=True, enable=True)
        resetVariables()
    except Exception as ex:
        om.MGlobal.displayWarning('You do not have a tail binded.')
        # unlock cleaning stage
        cmds.rowLayout(deleteHFreezeTrColumn, edit=True, enable=True)
        # unlock move directions
        cmds.rowLayout(moveYUpTab, edit=True, enable=True)
        cmds.rowLayout(moveXZTab, edit=True, enable=True)
        cmds.rowLayout(moveYDownTab, edit=True, enable=True)
        resetVariables()



# check if layer is visible or not, will return True or False.
def checklayerVisibility(layerName):
    if cmds.objExists(layerName):
        return cmds.getAttr(layerName + ".visibility")
    else:
        noLayers = print('NoLayersHaveObjects')
        return noLayers


def UnlockBindPoseStageIcon(*args):
    cmds.iconTextCheckBox(rigIconUnbindTail, edit=True, enable=True)
    resetVariables()


# Query the visibility of layers, and if so choose the obj within
def selectVisibleObj(*args):
    # Choose body parts by string name
    bodyPartLayersList = ['arm*', 'tail*', 'ear*', 'head*', 'leg*', 'body*']

    for i in bodyPartLayersList:
        # Select all layers with the names inside list
        selectBodylayers = cmds.ls(i, long=True, type='displayLayer')

        for l in selectBodylayers:
            # For each layer, query the status of its visibility
            visibilityStatus = checklayerVisibility(l)

            # If it is on,
            if visibilityStatus > 0:
                # List all the obj inside and select it
                activeList = cmds.editDisplayLayerMembers(l, query=True)
                for a in activeList:
                    chooseObj = cmds.ls(a, tr=True)
                    cmds.select(chooseObj, add=True)
    resetVariables()


# deselect current selection
def deselectAll(*args):
    cmds.select(clear=True)
    resetVariables()


# delete and freeze all of the chosen cat parts
def dAndFreeze(*args):
    # select all visible obj
    selectVisibleObj()
    cmds.delete(ch=True)
    cmds.makeIdentity(apply=True)
    deselectAll()
    cmds.button(goBackStageIcon, edit=True, enable=True, vis=True)
    cmds.rowLayout(deleteHFreezeTrColumn, edit=True, enable=False)
    #unlock stage 3
    cmds.columnLayout(stageThreeRigTab, edit=True, enable=True)
    om.MGlobal.displayWarning('You cleaned your cat while your cat tried to struggle and meow.')
    resetVariables()


# ask if there are any obj selected currently and return list
def QuerySelectedObj(*args):
    selectObjQuery = cmds.ls(selection=True)
    return bool(selectObjQuery)


# deletehistory on selected obj
def deleteHistory(*args):
    errorMessageSelect = 'You need to select your cat before scrubbing it! Press select all parts of the cat'
    if QuerySelectedObj():
        cmds.delete(ch=True)
        cmds.button(unlockLocationStageIcon, edit=True, enable=True, vis=True)
        om.MGlobal.displayWarning('Your cat is scrubbed and wet...but maybe it also needs to be dried.')
    else:
        om.MGlobal.displayWarning(errorMessageSelect)
    resetVariables()


def freezeTrans(*args):
    errorMessage = 'You need to select your cat before drying it! Press select all parts of the cat'
    try:
        cmds.makeIdentity(apply=True)
        cmds.button(unlockLocationStageIcon, edit=True, enable=True, vis=True)
        om.MGlobal.displayWarning('Your cat has been dried...have you scrubbed it yet?')
    except Exception as ex:
        om.MGlobal.displayWarning(errorMessage)
    resetVariables()


def UnlockLocationStageTab(*args):
    # mute freezing stage
    cmds.rowLayout(deleteHFreezeTrColumn, edit=True, enable=False)
    # unlock go back last stage
    cmds.button(goBackStageIcon, edit=True, enable=True, vis=True)
    resetVariables()
    # unlock stage 3
    cmds.columnLayout(stageThreeRigTab, edit=True, enable=True)

def goBackCleanStage(rowLayout, *args):
    rowLayoutEval = eval(rowLayout)
    cmds.rowLayout(rowLayoutEval, edit=True, enable=True)
    resetVariables()


# if performed other actions after moving Direction, reset global variables so moveSDirection can use again as default.
def resetVariables():
    global moveYUpCounter
    moveYUpCounter = 0


# move in directions given by icon
def moveSDirection(direction, *args):
    global moveYUpCounter
    YUp = 'YUp'
    YDown = 'YDown'
    X1 = 'X1'
    X0 = 'X0'
    Z1 = 'Z1'
    Z0 = 'Z0'
    translateZ = 'translateZ'
    translateY = 'translateY'
    translateX = 'translateX'
    errorMessage = 'Nothing is Selected!'
    baseDistance = 5
    displacementShorter = -3 + baseDistance

    # check if anything is selected
    selection = cmds.ls(selection=True)
    if not selection:
        om.MGlobal.displayError(errorMessage)
        return

    # if sth is chosen, move in given directions
    for chosenObj in selection:
        if direction == YUp:
            # if icon pressed less than 4 times,
            if moveYUpCounter < 2:
                # move by base distance (5)
                cmds.setAttr(chosenObj + '.' + translateY, cmds.getAttr(chosenObj + '.' + translateY) + baseDistance)
            # otherwise, if same command executed more than 3 times,
            elif moveYUpCounter >= 2:
                #    #move lesser on Y+ (2)
                cmds.setAttr(chosenObj + '.' + translateY,
                             cmds.getAttr(chosenObj + '.' + translateY) + displacementShorter)
        elif direction == YDown:
            # if icon pressed less than 4 times,
            if moveYUpCounter < 2:
                # move by base distance (5)
                cmds.setAttr(chosenObj + '.' + translateY, cmds.getAttr(chosenObj + '.' + translateY) - baseDistance)
            # otherwise, if same command executed more than 3 times,
            elif moveYUpCounter >= 2:
                #    #move lesser on Y+ (2)
                cmds.setAttr(chosenObj + '.' + translateY,
                             cmds.getAttr(chosenObj + '.' + translateY) - displacementShorter)
        elif direction == X1:
            # if icon pressed less than 4 times,
            if moveYUpCounter < 2:
                # move by base distance (5)
                cmds.setAttr(chosenObj + '.' + translateX, cmds.getAttr(chosenObj + '.' + translateX) + baseDistance)
            # otherwise, if same command executed more than 3 times,
            elif moveYUpCounter >= 2:
                #    #move lesser on X+ (2)
                cmds.setAttr(chosenObj + '.' + translateX,
                             cmds.getAttr(chosenObj + '.' + translateX) + displacementShorter)

        elif direction == X0:
            # if icon pressed less than 4 times,
            if moveYUpCounter < 2:
                # move by base distance (5)
                cmds.setAttr(chosenObj + '.' + translateX, cmds.getAttr(chosenObj + '.' + translateX) - baseDistance)
            # otherwise, if same command executed more than 3 times,
            elif moveYUpCounter >= 2:
                #    #move lesser on X- (2)
                cmds.setAttr(chosenObj + '.' + translateX,
                             cmds.getAttr(chosenObj + '.' + translateX) - displacementShorter)
        elif direction == Z1:
            # if icon pressed less than 4 times,
            if moveYUpCounter < 2:
                # move by base distance (5)
                cmds.setAttr(chosenObj + '.' + translateZ, cmds.getAttr(chosenObj + '.' + translateZ) + baseDistance)
            # otherwise, if same command executed more than 3 times,
            elif moveYUpCounter >= 2:
                #    #move lesser on Z+ (2)
                cmds.setAttr(chosenObj + '.' + translateZ,
                             cmds.getAttr(chosenObj + '.' + translateZ) + displacementShorter)
        elif direction == Z0:
            # if icon pressed less than 4 times,
            if moveYUpCounter < 2:
                # move by base distance (5)
                cmds.setAttr(chosenObj + '.' + translateZ, cmds.getAttr(chosenObj + '.' + translateZ) - baseDistance)
            # otherwise, if same command executed more than 3 times,
            elif moveYUpCounter >= 2:
                #    #move lesser on Z- (2)
                cmds.setAttr(chosenObj + '.' + translateZ,
                             cmds.getAttr(chosenObj + '.' + translateZ) - displacementShorter)
        # add 1 to how many times executed command
        moveYUpCounter = moveYUpCounter + 1



# move further when pressed two times move direction command (8)
def moveSDirectionTwice(direction, *args):
    global moveYUpCounter
    YUp = 'YUp'
    YDown = 'YDown'
    X1 = 'X1'
    X0 = 'X0'
    Z1 = 'Z1'
    Z0 = 'Z0'
    translateZ = 'translateZ'
    translateY = 'translateY'
    translateX = 'translateX'
    errorMessage = 'Nothing is Selected!'
    baseDistance = 5
    displacementFurther = 3 + baseDistance
    # check if anything is selected
    selection = cmds.ls(selection=True)
    if not selection:
        om.MGlobal.displayError(errorMessage)
        return

    # if sth is chosen, move in given directions
    for chosenObj in selection:
        if direction == YUp:
            cmds.setAttr(chosenObj + '.' + translateY, cmds.getAttr(chosenObj + '.' + translateY) + displacementFurther)
        elif direction == YDown:
            cmds.setAttr(chosenObj + '.' + translateY, cmds.getAttr(chosenObj + '.' + translateY) - displacementFurther)
        elif direction == X1:
            cmds.setAttr(chosenObj + '.' + translateX, cmds.getAttr(chosenObj + '.' + translateX) + displacementFurther)
        elif direction == X0:
            cmds.setAttr(chosenObj + '.' + translateX, cmds.getAttr(chosenObj + '.' + translateX) - displacementFurther)
        elif direction == Z1:
            cmds.setAttr(chosenObj + '.' + translateZ, cmds.getAttr(chosenObj + '.' + translateZ) + displacementFurther)
        elif direction == Z0:
            cmds.setAttr(chosenObj + '.' + translateZ, cmds.getAttr(chosenObj + '.' + translateZ) - displacementFurther)

    moveYUpCounter = moveYUpCounter + 1


def putDownLocatorFunc(*args):
    completedMessage= 'You placed a locator underneath your cat. Use the direction panel if you need to adjust it.'
    n='locatorCat'
    baseLocation = [0, -35.74, 0]
    createSpaceLocator= cmds.spaceLocator(n=n, p=baseLocation, a=True)
    cmds.xform(n, pivots=baseLocation)
    om.MGlobal.displayWarning(completedMessage)
    return createSpaceLocator

'''
FOLLOWING FUNCTIONS DETERMINE LOCATORS FOR THE CAT AND PLACE THEM WHEN EXCECUTED
'''
bboxes = []
LocationStartX = []
LocationStartY = []
LocationStartZ = []

#mathmatical function to calculate the selected obj bound box and return values
def queryNodesX(name='body', nodes=None, axis='x', mode='mid', *args):
    if not nodes:
        nodes = cmds.ls(name + '*', tr=True)
    if not nodes:
        om.MGlobal.displayError('nothingSelected')
        # select obj by name

    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ

    if axis == 'x':
        start = 0
    elif axis == 'y':
        start = 1
    elif axis == 'z':
        start = 2
    else:
        om.MGlobal.displayError('Unknown Axis')
    # get dimensions for selected obj
    for node in nodes:
        # get dimension for obj
        bbox = cmds.exactWorldBoundingBox(node)
        # append bbox value into bboxes
        bboxes.append(bbox)

        # select X/Y/Z values and show
        minValue = bbox[start]
        maxValue = bbox[start + 3]
        midValue = (maxValue + minValue) / 2
        if axis == 'x':
            LocationStartX.append(minValue)
            LocationStartX.append(maxValue)
            LocationStartX.append(midValue)
        elif axis == 'y':
            LocationStartY.append(minValue)
            LocationStartY.append(maxValue)
            LocationStartY.append(midValue)
        elif axis == 'z':
            LocationStartZ.append(minValue)
            LocationStartZ.append(maxValue)
            LocationStartZ.append(midValue)

'''
CREATE HEAD JOINT FUNCTIONS
'''

# get visible leg joints (chose HIERARCHY TOO)
def selectVisibleObjHead(*args):
    # Choose body parts by string name
    bodyPartLayersList = ['head*']

    for i in bodyPartLayersList:
        # Select all layers with the names inside list
        selectBodylayers = cmds.ls(i, long=True, type='displayLayer')

        for l in selectBodylayers:
            # For each layer, query the status of its visibility
            visibilityStatus = checklayerVisibility(l)

            # If it is on,
            if visibilityStatus > 0:
                # List all the obj inside and select it
                activeList = cmds.editDisplayLayerMembers(l, query=True)
                for a in activeList:
                    chooseObj = cmds.ls(a, tr=True)
                    listBodyPart = cmds.select(chooseObj, add=True, hierarchy=True)


def createHeadJoint1(*args):
    jointN = 'joint'
    bodyPart = 'head'
    number = '1'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjHead()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    headLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    headLocationY = LocationStartY[0] + 8
    queryNodesX(body, nodes=mySelection, axis='z')
    headLocationZ = LocationStartZ[2] -4

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + number, p=(headLocationX, headLocationY, headLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createHeadJoint2(*args):
    jointN = 'joint'
    bodyPart = 'head'
    number = '2'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjHead()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    headLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    headLocationY = LocationStartY[2] + 1
    queryNodesX(body, nodes=mySelection, axis='z')
    headLocationZ = LocationStartZ[2]

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + number, p=(headLocationX, headLocationY, headLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createEyeJointL(*args):
    jointN = 'joint'
    bodyPart = 'eye'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjHead()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    headLocationX = LocationStartX[2] + 10
    queryNodesX(body, nodes=mySelection, axis='y')
    headLocationY = LocationStartY[2] + 3
    queryNodesX(body, nodes=mySelection, axis='z')
    headLocationZ = LocationStartZ[2] + 10

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L, p=(headLocationX, headLocationY, headLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createEyeJointR(*args):
    jointN = 'joint'
    bodyPart = 'eye'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjHead()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    headLocationX = LocationStartX[2] - 10
    queryNodesX(body, nodes=mySelection, axis='y')
    headLocationY = LocationStartY[2] + 3
    queryNodesX(body, nodes=mySelection, axis='z')
    headLocationZ = LocationStartZ[2] + 10

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R, p=(headLocationX, headLocationY, headLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []
'''
CREATE HIP JOINT FUNCTIONS
'''
# create the hip Joint for start of body skeleton
def createHipJoint(*args):
    jointN = 'joint'
    bodyPart = 'hip'
    # number=0
    body = 'body'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ

    queryNodesX(body, axis='x')
    # get position values for hip location
    hipLocationX = LocationStartX[2]
    queryNodesX(body, axis='y')
    hipLocationY = LocationStartY[2] / 2
    queryNodesX(body, axis='z')
    hipLocationZ = LocationStartZ[2]

    '''location for where the Hipjoint should be if want to check:
    print(hipLocationX, hipLocationY, hipLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN, p=(hipLocationX, hipLocationY, hipLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createHipJoint1(*args):
    jointN = 'joint'
    bodyPart = 'hip'
    number='1'
    body = 'body'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ

    queryNodesX(body, axis='x')
    # get position values for hip location
    hipLocationX = LocationStartX[2]
    queryNodesX(body, axis='y')
    hipLocationY = LocationStartY[2] / 2 + 10
    queryNodesX(body, axis='z')
    hipLocationZ = LocationStartZ[2]

    '''location for where the Hipjoint should be if want to check:
    print(hipLocationX, hipLocationY, hipLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + number, p=(hipLocationX, hipLocationY, hipLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createHipJoint2(*args):
    jointN = 'joint'
    bodyPart = 'hip'
    number='2'
    body = 'body'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ

    queryNodesX(body, axis='x')
    # get position values for hip location
    hipLocationX = LocationStartX[2]
    queryNodesX(body, axis='y')
    hipLocationY = LocationStartY[2] / 2 + 10 + 15
    queryNodesX(body, axis='z')
    hipLocationZ = LocationStartZ[2]

    '''location for where the Hipjoint should be if want to check:
    print(hipLocationX, hipLocationY, hipLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + number, p=(hipLocationX, hipLocationY, hipLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []
'''
CREATE ARM JOINT FUNCTIONS
'''

# get visible leg joints (chose HIERARCHY TOO)
def selectVisibleObjArm(*args):
    # Choose body parts by string name
    bodyPartLayersList = ['arm*']

    for i in bodyPartLayersList:
        # Select all layers with the names inside list
        selectBodylayers = cmds.ls(i, long=True, type='displayLayer')

        for l in selectBodylayers:
            # For each layer, query the status of its visibility
            visibilityStatus = checklayerVisibility(l)

            # If it is on,
            if visibilityStatus > 0:
                # List all the obj inside and select it
                activeList = cmds.editDisplayLayerMembers(l, query=True)
                for a in activeList:
                    chooseObj = cmds.ls(a, tr=True)
                    listBodyPart = cmds.select(chooseObj, add=True, hierarchy=True)

def createArmJointR1(*args):
    jointN = 'joint'
    bodyPart = 'arm'
    number = '1'
    R = 'R'
    L = 'L'
    body = 'arm'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjArm()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)

    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    armLocationX = 0.4*LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    armLocationY = LocationStartY[2]+0.5*(LocationStartY[2])
    queryNodesX(body, nodes=mySelection, axis='z')
    armLocationZ = LocationStartZ[2]

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R + number, p=(armLocationX, armLocationY, armLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createArmJointL1(*args):
    jointN = 'joint'
    bodyPart = 'arm'
    number = '1'
    R = 'R'
    L = 'L'
    body = 'arm'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjArm()
    # choose if there are any obj with name R
    cmds.select(body + L + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)

    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    armLocationX = 0.4*LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    armLocationY = LocationStartY[2]+0.5*(LocationStartY[2])
    queryNodesX(body, nodes=mySelection, axis='z')
    armLocationZ = LocationStartZ[2]

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L + number, p=(armLocationX, armLocationY, armLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []
def createArmJointR2(*args):
    jointN = 'joint'
    bodyPart = 'arm'
    number = '2'
    R = 'R'
    L = 'L'
    body = 'arm'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjArm()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)

    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    armLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    armLocationY = LocationStartY[2]
    queryNodesX(body, nodes=mySelection, axis='z')
    armLocationZ = LocationStartZ[2]

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R + number, p=(armLocationX, armLocationY, armLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []


def createArmJointL2(*args):
    jointN = 'joint'
    bodyPart = 'arm'
    number = '2'
    R = 'R'
    L = 'L'
    body = 'arm'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjArm()
    # choose if there are any obj with name R
    cmds.select(body + L + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)

    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    armLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    armLocationY = LocationStartY[2]
    queryNodesX(body, nodes=mySelection, axis='z')
    armLocationZ = LocationStartZ[2]

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L + number, p=(armLocationX, armLocationY, armLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createArmJointR3(*args):
    jointN = 'joint'
    bodyPart = 'arm'
    number = '3'
    R = 'R'
    L = 'L'
    body = 'arm'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjArm()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)

    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    armLocationX = LocationStartX[1]-7
    queryNodesX(body, nodes=mySelection, axis='y')
    armLocationY = LocationStartY[2]-0.4*(LocationStartY[2])
    queryNodesX(body, nodes=mySelection, axis='z')
    armLocationZ = LocationStartZ[2]

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R + number, p=(armLocationX, armLocationY, armLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createArmJointL3(*args):
    jointN = 'joint'
    bodyPart = 'arm'
    number = '3'
    R = 'R'
    L = 'L'
    body = 'arm'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjArm()
    # choose if there are any obj with name R
    cmds.select(body + L + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)

    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    armLocationX = LocationStartX[0]+7
    queryNodesX(body, nodes=mySelection, axis='y')
    armLocationY = LocationStartY[2]-0.4*(LocationStartY[2])
    queryNodesX(body, nodes=mySelection, axis='z')
    armLocationZ = LocationStartZ[2]

    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L + number, p=(armLocationX, armLocationY, armLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []
'''
CREATE LEG JOINT FUNCTIONS
'''

# get visible leg joints (chose HIERARCHY TOO)
def selectVisibleObjLeg(*args):
    # Choose body parts by string name
    bodyPartLayersList = ['leg*']

    for i in bodyPartLayersList:
        # Select all layers with the names inside list
        selectBodylayers = cmds.ls(i, long=True, type='displayLayer')

        for l in selectBodylayers:
            # For each layer, query the status of its visibility
            visibilityStatus = checklayerVisibility(l)

            # If it is on,
            if visibilityStatus > 0:
                # List all the obj inside and select it
                activeList = cmds.editDisplayLayerMembers(l, query=True)
                for a in activeList:
                    chooseObj = cmds.ls(a, tr=True)
                    listBodyPart = cmds.select(chooseObj, add=True, hierarchy=True)


def createLegJointR1(*args):
    jointN = 'joint'
    bodyPart = 'leg'
    number = '1'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[1] - 8
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[2]

    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createLegJointL1(*args):
    jointN = 'joint'
    bodyPart = 'leg'
    number = '1'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name L
    cmds.select(body + L + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[1] - 8
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[2]

    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createLegJointR2(*args):
    jointN = 'joint'
    bodyPart = 'leg'
    number = '2'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[2]
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[2]-3

    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []
def createLegJointL2(*args):
    jointN = 'joint'
    bodyPart = 'leg'
    number = '2'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name L
    cmds.select(body + L + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[2]
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[2]-3

    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createLegJointR3(*args):
    jointN = 'joint'
    bodyPart = 'leg'
    number = '3'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[0]+6
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[2]-4

    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createLegJointL3(*args):
    jointN = 'joint'
    bodyPart = 'leg'
    number = '3'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name L
    cmds.select(body + L + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2]
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[0]+6
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[2]-4

    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []
'''
CREATEFOOTJOINTFUNCTIONS
'''
def createFootJointR1(*args):
    jointN = 'joint'
    bodyPart = 'foot'
    number = '1'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name R
    cmds.select(body + R + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2] - 1
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[0] + 4
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[1] - 4
    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + R + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []

def createFootJointL1(*args):
    jointN = 'joint'
    bodyPart = 'foot'
    number = '1'
    R = 'R'
    L = 'L'
    body = 'leg'
    global bboxes
    global LocationStartX
    global LocationStartY
    global LocationStartZ
    # run selection command to choose visible legs
    selectVisibleObjLeg()
    # choose if there are any obj with name R
    cmds.select(body + L + '*', deselect=True)
    # deselect highest group to only choose one leg
    cmds.select(body + 'A', deselect=True)
    cmds.select(body + 'B', deselect=True)
    mySelection = cmds.ls(sl=True)

    # select nodes by choosing selected bodypart
    queryNodesX(body, nodes=mySelection, axis='x')
    # get position values for hip location
    legLocationX = LocationStartX[2] - 1
    queryNodesX(body, nodes=mySelection, axis='y')
    legLocationY = LocationStartY[0] + 4
    queryNodesX(body, nodes=mySelection, axis='z')
    legLocationZ = LocationStartZ[1] - 4
    '''location for where the Legjoint should be if want to check:
         print(legLocationX, legLocationY, legLocationZ)'''
    # create joint with the given position
    cmds.select(deselect=True)
    cmds.joint(n=bodyPart + jointN + L + number, p=(legLocationX, legLocationY, legLocationZ))
    # empty list after performing action
    bboxes = []
    LocationStartX = []
    LocationStartY = []
    LocationStartZ = []
# function to execute when building joint points
def createJointPositions(*args):
    createHeadJoint2()
    cmds.select(deselect=True)
    createEyeJointL()
    cmds.select(deselect=True)
    createEyeJointR()
    cmds.select(deselect=True)
    createHeadJoint1()
    cmds.select(deselect=True)
    createHipJoint2()
    cmds.select(deselect=True)
    createArmJointR1()
    cmds.select(deselect=True)
    createArmJointR2()
    cmds.select(deselect=True)
    createArmJointR3()
    cmds.select(deselect=True)
    createArmJointL1()
    cmds.select(deselect=True)
    createArmJointL2()
    cmds.select(deselect=True)
    createArmJointL3()
    cmds.select(deselect=True)
    createHipJoint1()
    cmds.select(deselect=True)
    createHipJoint()
    cmds.select(deselect=True)
    createLegJointR1()
    cmds.select(deselect=True)
    createLegJointR2()
    cmds.select(deselect=True)
    createLegJointR3()
    cmds.select(deselect=True)
    createFootJointR1()
    cmds.select(deselect=True)
    createLegJointL1()
    cmds.select(deselect=True)
    createLegJointL2()
    cmds.select(deselect=True)
    createLegJointL3()
    cmds.select(deselect=True)
    createFootJointL1()
    cmds.select(deselect=True)

    resetVariables()





#choose joints and cleanup them by making orientation follow the same+ add parent constraints
#get ready for skinning
def cleanUpChain( *args):
    #list for joints and constraints, used to call list easily
    global jnts
    global constraint
    #select chain of joint
    newChain= cmds.ls(sl=1, type='joint')
    #for each joint chosen in the chain,
    for obj in newChain:
        cmds.select(cl=1)
        newJoint = cmds.joint(n='%s_skin'%obj)
        pConstraintA = cmds.parentConstraint(obj, newJoint, mo=0)
        cmds.delete(pConstraintA)
        cmds.makeIdentity (newJoint, apply=1)
        pConstraintB = cmds.parentConstraint(obj, newJoint, mo=0)
        jnts.append(newJoint)
        constraint.append(pConstraintB)


def combineBody(*args):
    resetVariables()
    pass
    '''seehere'''


def undoLast(*args):
    resetVariables()
    cmds.undo()


def redoLast(*args):
    resetVariables()
    cmds.redo()


'''
    get paths for images
    get the path Name for images to be loaded into GUI, needs to be chosen automatically when running the python.
    BE SURE TO CHOOSE IMAGES SORTED BY NAME: EAR-HEAD-LEG-TAIL-ICONS
'''
# Global Variables
getpath = cmds.fileDialog2(dir='path/to/dir', dialogStyle=2, fileMode=4)
earPicA = str(getpath[0])
earPicB = str(getpath[1])
earPicC = str(getpath[2])
earPicD = str(getpath[3])
headPicA = str(getpath[4])
headPicB = str(getpath[5])
headPicC = str(getpath[6])
headPicD = str(getpath[7])
legPicA = str(getpath[8])
legPicB = str(getpath[9])
tailPicA = str(getpath[10])
tailPicB = str(getpath[11])
tailPicC = str(getpath[12])
tailPicD = str(getpath[13])
uIconPicA = str(getpath[14])
uIconPicB = str(getpath[15])
uIconPicC = str(getpath[16])
uIconPicD = str(getpath[17])
uIconPicE = str(getpath[18])
uIconPicF = str(getpath[19])
uIconPicG = str(getpath[20])
uIconPicH = str(getpath[21])
uIconPicI = str(getpath[22])
uIconPicJ = str(getpath[23])
uIconPicK = str(getpath[24])
uIconPicL = str(getpath[25])
uIconPicM = str(getpath[26])
uIconPicN = str(getpath[27])
uIconPicO = str(getpath[28])
uIconPicP = str(getpath[29])
uIconPicQ = str(getpath[30])

'''creating the GUI window'''


window = cmds.window(title="Catgenerator", bgc=(0.2, 0.7, 0.9), iconName='catGen', w=530, h=1050)
parentLayout = cmds.scrollLayout('main', cr=True, w=450, h=300)
tabs = cmds.tabLayout(innerMarginWidth=5, innerMarginHeight=5)
# create column tab for Modeling Tab
child1 = cmds.columnLayout(rowSpacing=0,
                           bgc=(0.2, 0.7, 0.9), adj=True, cal='center')
cmds.text('Cat Generator', h=50)

'''
icon shown when in rigging mode
'''
rigColumnModel = cmds.columnLayout('rigModeModel', adj=True,
                                   p=child1, bgc=(0.8, 0.3, 0.4),
                                   vis=False)
rigIconModel = cmds.iconTextCheckBox(al='left', vis=True,
                                     l='You have already agreed to adopting your current cat, do not make it sad!',
                                     m=True, st='iconAndTextHorizontal', image=uIconPicC, ua=True,
                                     onc=partial(enablecheckBoxGrpvis, 'returnIconModel'),
                                     ofc=partial(disablecheckBoxGrpvis, 'returnIconModel'))
returnIconModel = cmds.checkBoxGrp(numberOfCheckBoxes=2, label='Are you sure you want to adopt another cat?',
                                   labelArray2=['Yes, I do not like my cat anymore', 'No, let me consider again'],
                                   v1=False, v2=False,
                                   on1=partial(disableColumnLayoutvis, rigColumnModel),
                                   on2=partial(disablecheckBoxGrpvis, 'returnIconModel'),
                                   sbm='You will lose your rig and need to redo the rigging process!',
                                   cl3=['left', 'left', 'left'], cw3=[210, 170, 50], vis=False)
cmds.setParent('..')

'''
GUI FACE PORTION
'''
# create single grid layout for showing face type text
cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child1, bgc=(0.2, 0.8, 0.9))
cmds.text('------>')
cmds.text('Select Face Type')
cmds.text('<------')
cmds.setParent('..')

# create 1 row with the row layout to show face type icons
shfFace = cmds.rowLayout(p=child1, numberOfColumns=4, bgc=(0.2, 0.8, 0.9))
shfFace1 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=headPicA, label='faceA',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseFaceA))
shfFace2 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=headPicB, label='faceB',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseFaceB), ofc=(chooseFaceA))
shfFace3 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=headPicC, label='faceC',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseFaceC), ofc=(chooseFaceA))
shfFace4 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=headPicD, label='faceD',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseFaceD), ofc=(chooseFaceA))

cmds.setParent('..')

'''
GUI EAR PORTION
'''
# create single grid layout for showing ear type text
cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child1, bgc=(0.9, 0.7, 0.9))
cmds.text('------>')
cmds.text('Select Ear Type')
cmds.text('<------')
cmds.setParent('..')

# create 1 row with the row layout to show ear type icons
shfEar = cmds.rowLayout(p=child1, numberOfColumns=4, bgc=(0.9, 0.7, 0.9))
shfEar1 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=earPicA, label='earA', olc=[.3, .3, .3],
                                mw=90, mh=90, onc=(chooseEarA))
shfEar2 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=earPicB, label='earB', olc=[.3, .3, .3],
                                mw=90, mh=90, onc=(chooseEarB), ofc=(chooseEarA))
shfEar3 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=earPicC, label='earC', olc=[.3, .3, .3],
                                mw=90, mh=90, onc=(chooseEarC), ofc=(chooseEarA))
shfEar4 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=earPicD, label='earD', olc=[.3, .3, .3],
                                mw=90, mh=90, onc=(chooseEarD), ofc=(chooseEarA))
cmds.setParent('..')

'''
GUI ARM PORTION
'''
cmds.columnLayout('arm', adj=True, p=child1, bgc=(0.8, 0.3, 0.4))
armSlider = cmds.floatSliderGrp(field=True, label='Arm Length', minValue=0.7, maxValue=1.1, fieldMinValue=1,
                                fieldMaxValue=10, pre=2, value=0.8, step=1, dragCommand=changeArmLength)
cmds.setParent('..')

'''
GUI BODY PORTION
'''
cmds.columnLayout('body', adj=True, p=child1, bgc=(0.5, 0.5, 0.8))
bodySlider = cmds.floatSliderGrp(field=True, label='Body Thickness', minValue=0.9, maxValue=1.1, fieldMinValue=1,
                                 fieldMaxValue=10, pre=2, value=1, step=1, dragCommand=changeBodyThickness)
cmds.setParent('..')

'''
GUI LEG PORTION
'''
# create single grid layout for showing leg type text
cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child1, bgc=(0.9, 0.5, 0.3))
cmds.text('------>')
cmds.text('Select Leg Type')
cmds.text('<------')
cmds.setParent('..')
# select leg type
shfLeg = cmds.rowLayout(p=child1, numberOfColumns=3, bgc=(0.9, 0.5, 0.3))
# align the two leg types so they would the same in GUI layout
cmds.text('                                             ')
shfLeg1 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=legPicA, label='legA', olc=[.3, .3, .3],
                                mw=90, mh=90, onc=(chooseLegA))
shfLeg2 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=legPicB, label='legB', olc=[.3, .3, .3],
                                mw=90, mh=90, onc=(chooseLegB), ofc=(chooseLegA))
cmds.setParent('..')
# change leg range
cmds.columnLayout('leg', adj=True, p=child1, bgc=(0.9, 0.5, 0.3))
legSlider = cmds.floatSliderGrp(field=True, label='Leg Length', minValue=0.96, maxValue=1.25, fieldMinValue=1,
                                fieldMaxValue=10, pre=2, value=1, step=1, dragCommand=changeLegLength)
cmds.setParent('..')

'''
GUI TAIL PORTION
'''
# create single grid layout for showing tail type text
cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child1, bgc=(0.9, 0.8, 0.3))
cmds.text('------>')
cmds.text('Select Tail Type')
cmds.text('<------')
cmds.setParent('..')
# create 1 row with the row layout to show tail type icons
shfTail = cmds.rowLayout(p=child1, numberOfColumns=4, bgc=(0.9, 0.8, 0.3))
shfTail1 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=tailPicA, label='tailA',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseTailA))
shfTail2 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=tailPicB, label='tailB',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseTailB), ofc=(chooseTailA))
shfTail3 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=tailPicC, label='tailC',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseTailC), ofc=(chooseTailA))
shfTail4 = cmds.iconTextCheckBox(style='iconAndTextVertical', image1=tailPicD, label='tailD',
                                 olc=[.3, .3, .3], mw=90, mh=90, onc=(chooseTailD), ofc=(chooseTailA))
cmds.setParent('..')
# set sliders for the tail to curve and lengthen
cmds.columnLayout(adjustableColumn=True, p=child1, bgc=(0.9, 0.8, 0.3))
tailCurveSlider = cmds.intSliderGrp(l='Tail Curvation', min=0, max=40, value=0, step=1, dragCommand=tailCurl)
tailStretchSlider = cmds.floatSliderGrp(label='Tail Length', minValue=0.46, maxValue=1.56, pre=2, value=1, step=1,
                                        dragCommand=tailStretch)
cmds.setParent('..')

'''
GUI FOR UNDO & REDO, MODELING TAB
'''
undoLayoutModel = cmds.rowLayout(p=child1, numberOfColumns=2, ct2=['left', 'right'], co2=[200, 250])
undoIconModel = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicD, label='Undo', ua=True,
                                    olc=[.3, .3, .3], mw=90, mh=90, c=undoLast)
redoIconModel = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicE, label='Redo', ua=True,
                                    olc=[.3, .3, .3], mw=90, mh=90, c=redoLast)
cmds.setParent('..')

cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child1, bgc=(0.9, 0.7, 0.9))
cmds.text('&&&&&&')
cmds.text('created by Sophia Johnson')
cmds.text('&&&&&&')
cmds.setParent('..')
cmds.setParent('..')

'''
GUI COLORING PORTION, Coloring tab
'''

child2 = cmds.columnLayout(rowSpacing=30,
                           bgc=(0.2, 0.6, 0.5), adj=True, cal='center')
cmds.columnLayout(adjustableColumn=True, p=child2, bgc=(0.5, 0.6, 0.3))
cmds.text(label='Pick a color!', fn='boldLabelFont', h=50)
n_color = cmds.colorInputWidgetGrp(label='Color', rgb=(1, 0, 0))
cmds.button(l='generate Base Color', command=assignColorBase)
cmds.button(l='generate Hat Color', command=assignColorHead)
cmds.button(l='generate Iris Color', command=assignColorIris)
cmds.button(l='generate Eye White Color', command=assignColorEye)
cmds.button(label='clear All Colors and start over again!', command=(assignMaterialsToOne))
cmds.setParent('..')

'''
GUI FOR UNDO & REDO, COLORING TAB
'''
undoLayoutColor = cmds.rowLayout(p=child2, numberOfColumns=2, ct2=['left', 'right'], co2=[200, 250])
undoIconColor = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicD, label='Undo', ua=True,
                                    olc=[.3, .3, .3], mw=90, mh=90, c=undoLast)
redoIconColor = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicE, label='Redo', ua=True,
                                    olc=[.3, .3, .3], mw=90, mh=90, c=redoLast)
cmds.setParent('..')

cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child2, bgc=(0.9, 0.7, 0.9))
cmds.text('&&&&&&')
cmds.text('created by Sophia Johnson')
cmds.text('&&&&&&')
cmds.setParent('..')
cmds.setParent('..')

'''
GUI RIG PORTION, rigging tab
'''
child3 = cmds.columnLayout(rowSpacing=0,
                           bgc=(0.9, 0.7, 0.9), adj=True, cal='center')
cmds.text('Rigging', h=50)
'''
GUI RIG, STAGE 0: MUTE MODEL TAB
'''
rigIconRig = cmds.iconTextCheckBox(al='left',
                                   l='by checking this box, I ensure I want to adopt the cat and I want to proceed with the rigging process.',
                                   m=True, st='iconAndTextHorizontal', image=uIconPicB, si=uIconPicA, ua=True,
                                   onc=partial(enableColumnLayoutvis, rigColumnModel))
cmds.setParent('..')

'''
GUI RIG, STAGE 1: GO TO BIND POSE AND UNBIND TAIL
'''
rigStartColumn = cmds.columnLayout(adjustableColumn=True, p=child3, enable=False)
rigIconUnbindTail = cmds.iconTextCheckBox(al='left',
                                          l='1. Go to Bind Pose and Unbind Tail Joints',
                                          m=True, st='iconAndTextHorizontal', image=uIconPicB, si=uIconPicA, ua=True,
                                          onc=unbindTail)
# press button to unlock step 1 Unbind Tail Joints
unlockBindTailIcon = cmds.button(
    l='↑unlock Step 1 again(will not undo what you have done already, press Undo if needed)↑',
    vis=False, command=UnlockBindPoseStageIcon, bgc=(0.2, 0.8, 0.6))
cmds.setParent('..')

'''
GUI RIG, STAGE 2: DELETE ALL HISTORY AND FREEZE TRANSFORMATIONS
'''
cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child3, bgc=(0.2, 0.7, 0.8))
cmds.text('------>')
cmds.text('2. Cleaning Time!')
cmds.text('<------')
cmds.setParent('..')

# options for deleting history, freezing transformations, and doing it all at once.
deleteHFreezeTrColumn = cmds.rowLayout(p=child3, numberOfColumns=5, ct3=['left', 'left', 'left'],
                                       co3=[0, 20, 0], bgc=(0.2, 0.7, 0.8), enable=False)
deleteFreezeAll = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicF,
                                      label='Delete all history and freeze transformation!', ua=True,
                                      olc=[.3, .3, .3], mw=90, mh=90, c=dAndFreeze)
selectAllLiveObjIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicJ,
                                           label='Select all', ua=True,
                                           olc=[.3, .3, .3], mw=90, mh=90, c=selectVisibleObj)
deselectAllLiveObjIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicI,
                                             label='Deselect', ua=True,
                                             olc=[.3, .3, .3], mw=90, mh=90, c=deselectAll)
deleteH = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicH,
                              label='Delete history?', ua=True,
                              olc=[.3, .3, .3], mw=90, mh=90, c=deleteHistory)
freezeT = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicG,
                              label='Freeze transformations.', ua=True,
                              olc=[.3, .3, .3], mw=90, mh=90, c=freezeTrans)
cmds.setParent('..')


# show icon to unlock next stage
unlockLocationStageIcon = cmds.button(l='↓unlock next stage↓', vis=False,
                                      command=UnlockLocationStageTab, bgc=(0.2, 0.8, 0.6))
# unlock after clicking unlockLocationStage to go back
goBackStageIcon = cmds.button(l='↑go back to last stage(will not undo what you did)↑',
                              vis=False, command=partial(goBackCleanStage, 'deleteHFreezeTrColumn'),
                              bgc=(0.7, 0.3, 0.6))

'''
GUI RIG, STAGE 3: LOCATE OBJ
'''
cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child3, bgc=(0.8, 0.5, 0.6))
cmds.text('------>')
cmds.text('3. Locate Your Cat!')
cmds.text('<------')
cmds.setParent('..')

stageThreeRigTab = cmds.columnLayout(adjustableColumn=True, p=child3, enable=False)
putDownLocatorIcon = cmds.button(
    l='Put down locator to determine where your cat is in the world!',
    vis=True, command=putDownLocatorFunc, bgc=(0.8, 0.5, 0.6))
createJointsIcon = cmds.button(
    l='Automatically generate joint points to determine where the joints of your cat are',
    vis=True, command=createJointPositions, bgc=(0.8, 0.5, 0.6))

'''
GUI RIG, STAGE ?: COMBINE ALL MESH, SKIN
'''
rigIconCombineBody = cmds.iconTextCheckBox(al='left',
                                           l='*STILL TESTING*Get ready for skinning by adding parent constraints & orientate joints',
                                           bgc=(0.2, 0.7, 0.9),
                                           m=True, st='iconAndTextHorizontal', image=uIconPicB, si=uIconPicA, ua=True,
                                           onc=cleanUpChain)
rigIconCombineBody = cmds.iconTextCheckBox(al='left',
                                           l='*STILL TESTING* Combine Body Mesh for Your Cat!(tail excluded)', bgc=(0.2, 0.7, 0.9),
                                           m=True, st='iconAndTextHorizontal', image=uIconPicB, si=uIconPicA, ua=True,
                                           onc=combineBody)
cmds.setParent('..')
'''
GUI RIG, DIRECTION MOVE (UNLOCK IN STAGE 3)
explanation: base distance- by default selection moves by 5. 
            If direction button pressed more than 2 times, the distance will be reduced to 2 when moving in any direction
            to increase sensitivity.
            Doubleclicking allows selection to move by 8.
            Performing any other Action in the Rig Tab will set the move distance back to base distance (5).
'''

# YUp Icon
moveYUpTab = cmds.rowLayout(p=child3, numberOfColumns=3, ct3=['left', 'left', 'left'], co3=[225, 0, 0], enable=False)
moveYUpIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicK, label='YUp', ua=True,
                                  rpt=True, dcc=partial(moveSDirectionTwice, 'YUp'),
                                  olc=[.3, .3, .3], mw=90, mh=90, c=partial(moveSDirection, 'YUp'), al='center')
cmds.text('                        ')
showDirectionIcon = cmds.image(image=uIconPicO)
cmds.setParent('..')
# XZ Axis
moveXZTab = cmds.rowLayout(p=child3, numberOfColumns=5, ct5=['left', 'left', 'left', 'right', 'right'],
                           co5=[100, 0, 0, 0, 0], enable=False)
moveZDownIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicL, label='+Z', ua=True,
                                    olc=[.3, .3, .3], mw=90, mh=90, al='center',
                                    c = partial(moveSDirection, 'Z1'),
                                    dcc = partial(moveSDirectionTwice, 'Z1'))

moveZUpIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicP, label='-Z', ua=True,
                                  olc=[.3, .3, .3], mw=90, mh=90, al='center',
                                    c = partial(moveSDirection, 'Z0'),
                                    dcc = partial(moveSDirectionTwice, 'Z0'))

cmds.text('                              ')
moveXRIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicQ, label='-X', ua=True,
                                 olc=[.3, .3, .3], mw=90, mh=90, al='center',
                                    c = partial(moveSDirection, 'X0'),
                                    dcc = partial(moveSDirectionTwice, 'X0'))
moveXLIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicN, label='X', ua=True,
                                 olc=[.3, .3, .3], mw=90, mh=90, al='center',
                                    c = partial(moveSDirection, 'X1'),
                                    dcc = partial(moveSDirectionTwice, 'X1'))
cmds.setParent('..')
# YDown Icon
moveYDownTab = cmds.rowLayout(p=child3, numberOfColumns=1, ct1='left', co1=225, enable=False)
moveYDownIcon = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicM, label='YDown', ua=True,
                                    olc=[.3, .3, .3], mw=90, mh=90, al='center',
                                        c=partial(moveSDirection, 'YDown'),
                                        dcc=partial(moveSDirectionTwice, 'YDown'))
cmds.setParent('..')

'''
GUI FOR UNDO & REDO, RIGGING TAB
'''
undoLayoutRigging = cmds.rowLayout(p=child3, numberOfColumns=2, ct2=['left', 'right'], co2=[200, 250])
undoIconRig = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicD, label='Undo', ua=True,
                                  olc=[.3, .3, .3], mw=90, mh=90, c=undoLast)
redoIconRig = cmds.iconTextButton(style='iconAndTextVertical', image1=uIconPicE, label='Redo', ua=True,
                                  olc=[.3, .3, .3], mw=90, mh=90, c=redoLast)
cmds.setParent('..')

cmds.gridLayout(numberOfColumns=3, cellWidthHeight=(170, 40), parent=child3, bgc=(0.9, 0.7, 0.9))
cmds.text('&&&&&&')
cmds.text('created by Sophia Johnson')
cmds.text('&&&&&&')
cmds.setParent('..')

cmds.setParent(parentLayout)
cmds.tabLayout(tabs, edit=True, tabLabel=((child1, 'Modeling'),
                                          (child2, 'Coloring'), (child3, 'Rigging')), bgc=(0.2, 0.2, 0.4))
cmds.showWindow(window)
